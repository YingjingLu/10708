# Mixture-of-Experts-Models

Future work:
 - Add Mixture Density Neural Network using tensorflow
 - Rewrite HME with tensorflow
 
 
##  Hierarchical Mixture of Experts

Hierarchical mixture of experts can be used to solve standard [regression](https://github.com/AmazaspShumik/Mixture-of-Experts-Models/blob/master/Hierarchical%20Mixture%20of%20Experts/hme_standard_regression_examples.ipynb) and [classification](https://github.com/AmazaspShumik/Mixture-of-Experts-Models/blob/master/Hierarchical%20Mixture%20of%20Experts/hme_classification_examples.ipynb) problems, however one of the main applications of hme are problems with [multimodal output](https://github.com/AmazaspShumik/Mixture-of-Experts-Models/blob/master/Hierarchical%20Mixture%20of%20Experts/hme_multimodal_output_examples.ipynb).






[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/AmazaspShumik/mixture-models/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

